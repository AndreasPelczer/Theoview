//
//  ContentView.swift
//  CameraView
//
//  Created by Andreas Pelczer on 28.01.24.
//

import SwiftUI

struct ContentView: View {
    @State private var photo: UIImage?
    @State private var showCameraView = false
    
    var body: some View {
        VStack {
            if let photo = self.photo {
                ZStack {
                    // Hintergrund: Gespiegeltes Bild
                    Image(uiImage: photo)
                        .resizable()
                        .scaledToFit()
                        .scaleEffect(x: -1, y: 1) // Horizontales Spiegeln des Bildes
                    
                    // Vordergrund: Originalbild mit 50% Transparenz
                    Image(uiImage: photo)
                        .resizable()
                        .scaledToFit()
                        .opacity(0.5) // Setzen der Transparenz auf 50%
                }
            }
            Spacer()
            Button("Show Camera") {
                showCameraView = true
            }
            Button("Bild speichern") {
            }
            .sheet(isPresented: $showCameraView) {
                CameraView(photo: $photo, takePhoto: { image in
                    // Speichern des Bildes in den eigenen Bildern
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                })
            }

            .padding()
        }
    }

    // Methode zum Verarbeiten des Ergebnisses des Bildspeichervorgangs
    func image(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
        if let error = error {
            // Fehler beim Speichern des Bildes
            print("Fehler beim Speichern des Bildes:", error.localizedDescription)
        } else {
            // Bild wurde erfolgreich gespeichert
            print("Bild wurde erfolgreich gespeichert.")
        }
    }
    
}
